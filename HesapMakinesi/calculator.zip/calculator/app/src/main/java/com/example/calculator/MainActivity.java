package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText ekran;
    Button sifir,nokta,esittir;
    Button bir,iki,uc,dort,bes,alti,yedi,sekiz,dokuz;
    Button toplama,cikarma,carpma,bolme;


    Float deger1,deger2;
    Boolean carp=false,bol=false,topla=false,cikar=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ekran=findViewById(R.id.txtEkran);
        ekran.setShowSoftInputOnFocus(false);

        sifir=findViewById(R.id.buttonsifir);
        bir=findViewById(R.id.buttonbir);
        iki=findViewById(R.id.buttoniki);
        uc=findViewById(R.id.buttonuc);
        dort=findViewById(R.id.buttondort);
        bes=findViewById(R.id.buttonbes);
        alti=findViewById(R.id.buttonalti);
        yedi=findViewById(R.id.buttonyedi);
        sekiz=findViewById(R.id.buttonsekiz);
        dokuz=findViewById(R.id.buttondokuz);

        nokta=findViewById(R.id.buttonnokta);
        esittir=findViewById(R.id.buttonesittir);

        toplama=findViewById(R.id.buttonarti);
        cikarma=findViewById(R.id.buttoneksi);
        carpma=findViewById(R.id.buttoncarp);
        bolme=findViewById(R.id.buttonbol);

        toplama.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ekran==null){
                    ekran.setText("");
                }else{
                    deger1=Float.parseFloat(ekran.getText()+"");
                    topla=true;
                    ekran.setText(null);
                }
            }
        });
        cikarma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                deger1=Float.parseFloat(ekran.getText()+"");
                cikar=true;
                ekran.setText(null);

            }
        });
        carpma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                deger1=Float.parseFloat(ekran.getText()+"");
                carp=true;
                ekran.setText(null);

            }
        });
        bolme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                deger1=Float.parseFloat(ekran.getText()+"");
                bol=true;
                ekran.setText(null);

            }
        });
        esittir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deger2=Float.parseFloat(ekran.getText()+"");
                if(topla==true){
                    ekran.setText(String.valueOf(deger1+deger2));
                    topla=false;
                }
                if(cikar==true){
                    ekran.setText(String.valueOf(deger1-deger2));
                    cikar=false;
                }
                if(carp==true){
                    ekran.setText(String.valueOf(deger1*deger2));
                    carp=false;
                }
                if(bol==true){
                    ekran.setText(String.valueOf(deger1/deger2));
                    bol=false;
                }
            }
        });


    }
    public void sifir(View view){
        ekran.setText(ekran.getText()+"0");
    }
    public void bir(View view){
        ekran.setText(ekran.getText()+"1");
    }
    public void iki(View view){
        ekran.setText(ekran.getText()+"2");
    }
    public void uc(View view){
        ekran.setText(ekran.getText()+"3");
    }
    public void dort(View view){
        ekran.setText(ekran.getText()+"4");
    }
    public void bes(View view){
        ekran.setText(ekran.getText()+"5");
    }
    public void alti(View view){
        ekran.setText(ekran.getText()+"6");
    }
    public void yedi(View view){
        ekran.setText(ekran.getText()+"7");
    }
    public void sekiz(View view){
        ekran.setText(ekran.getText()+"8");
    }
    public void dokuz(View view){
        ekran.setText(ekran.getText()+"9");
    }
    public void nokta(View view){
        ekran.setText(ekran.getText()+".");
    }

    public void temizle(View view){
        ekran.setText("");
    }

    public void gerial(View view){
        int cursorPos=ekran.getSelectionStart();
        if(cursorPos>0){
            String eskideger=ekran.getText().toString();
            String soltaraf=eskideger.substring(0,cursorPos-1);
            String sagtaraf=eskideger.substring(cursorPos);
            String yenideger=soltaraf+sagtaraf;
            ekran.setText(yenideger);
            ekran.setSelection(cursorPos-1);
        }

}
}